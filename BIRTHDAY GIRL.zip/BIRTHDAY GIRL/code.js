function openBox(box) {
  box.classList.toggle('open');
}
